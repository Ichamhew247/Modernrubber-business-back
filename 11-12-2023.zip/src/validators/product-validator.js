// const Joi = require("joi");

// const validate = require("./validate");

// const productSchema = Joi.object({
//   customerCode: Joi.string().required(),
//   companyName: Joi.string().required(),
//   address: Joi.string().required(),
//   email: Joi.string().required(),
//   contactNumber: Joi.string().required(),
//   note: Joi.string().required(),
// });

// exports.validateProductSchema = validate(productSchema);
