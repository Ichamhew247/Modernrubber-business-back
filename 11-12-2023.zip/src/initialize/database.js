const db = require("../models");
db.sequelize.sync({ force: false }).then(() => {
  console.log("yes re-sync done");
});
